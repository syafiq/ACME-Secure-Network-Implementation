#!/bin/bash

S1=`cat /var/log/snort/alert.timestamp`
S2=`ls -lah /var/log/snort/alert | awk '{ print $6 $7 $8 }'`
if [ $S1 == $S2 ]
then
	echo "No Email"
else
	echo "Log File has changed - sending email"
	echo "$S1"
	echo "$S2"
	sendmail syafiq132@gmail.com,philip.93.3@gmail.com,antoinehonor@gmail.com -i <<EOF
From:VM1
Subject:IDS Activity detectet
$(tail -n 24 /var/log/snort/alert)
EOF

	ls -lah /var/log/snort/alert | awk '{ print $6 $7 $8 }' > /var/log/snort/alert.timestamp
fi
